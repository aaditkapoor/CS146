// Josephus.java: Takes N and M from the command line and prints out the order 
// in which people are eliminated (and thus would show Josephus where to sit in 
// the circle).

import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;

public class Josephus {
    public static void main(String[] args) {

}
