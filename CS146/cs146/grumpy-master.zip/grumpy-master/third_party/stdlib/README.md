Canonical versions of the files in this folder come from the
[Lib](https://github.com/python/cpython/tree/2.7/Lib) directory of the
[2.7 branch of the CPython repo](https://github.com/python/cpython/tree/2.7).
