The source code in this directory is forked from github.com/pybee/ouroboros. There are very light modifications to the source code so that it will work with Grumpy.
