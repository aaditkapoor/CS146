Canonical versions of the files in this folder come from the
[lib-python/2.7](https://bitbucket.org/pypy/pypy/src/23fd2966aada422b331d7d752fc383178deffb27/lib-python/2.7/?at=default)
directory of the [PyPy repo](https://bitbucket.org/pypy/pypy).
