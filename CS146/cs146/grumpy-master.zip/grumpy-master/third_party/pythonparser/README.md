The source code in this directory is forked from
[github.com/m-labs/pythonparser](https://github.com/m-labs/pythonparser).
There are very light modifications to the source code so that it will work with
Grumpy.
