This directory contains Grumpy Python standard library code. It is only expected
to run under Grumpy, not CPython.
